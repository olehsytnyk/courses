﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace STP.Identity.Persistence.Migrations.ApplicationDB
{
    public partial class Migr2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
