﻿using STP.Interfaces.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace STP.Identity.Domain.DTOs.User
{
    public class UserDto : BaseUserDto
    {
        public string Id { get; set; }
    }
}
