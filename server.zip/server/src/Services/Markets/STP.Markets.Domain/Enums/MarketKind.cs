﻿using System;
using System.Collections.Generic;
using System.Text;

namespace STP.Markets.Domain {
    public enum MarketKind {
        Default,
        Crypto,
        Stocks,
        Currencies
    }
}
