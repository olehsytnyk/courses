﻿using System;
using System.Collections.Generic;
using System.Text;

namespace STP.Markets.Domain {
    public enum Currency {
        Default,
        AUD,
        CAD,
        EUR,
        GBP,
        JPY,
        UAH,
        USD
    }
}
