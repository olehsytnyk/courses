﻿using STP.Interfaces.Messages;

namespace STP.Markets.Application
{
    public class WatchlistDtoI : WatchlistDto, IMessage
    {
    }
}
