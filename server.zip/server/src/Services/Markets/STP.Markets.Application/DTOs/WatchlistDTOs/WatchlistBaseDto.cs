﻿using System;
using System.Collections.Generic;
using System.Text;

namespace STP.Markets.Application {
    public class WatchlistBaseDto {
        public string Name { get; set; }
    }
}
