﻿using System;
using System.Collections.Generic;
using System.Text;

namespace STP.Markets.Application.Enums {
    public enum PutAction {
        Add,
        Remove
    }
}
