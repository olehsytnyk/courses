﻿namespace STP.Realtime.Common.WebSocketMessages
{
    public class SocketMessageTransfer
    {
        public Exchange Subject;
        public string SubjectId;
        public object Data;
    }
}
