﻿namespace STP.Realtime.Common.WebSocketMessages
{
   public class SocketMessageResult
    {
        public string RequestId;
        public bool Result;
    }
}