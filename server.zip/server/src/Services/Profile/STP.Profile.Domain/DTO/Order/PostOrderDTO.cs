﻿using System;
using System.Collections.Generic;
using System.Text;

namespace STP.Profile.Domain.DTO.Order
{
    public class PostOrderDTO : BaseOrderDTO
    {
    }
}
