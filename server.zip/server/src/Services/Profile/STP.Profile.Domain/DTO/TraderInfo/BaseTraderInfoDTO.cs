﻿namespace STP.Profile.Domain.DTO.TraderInfo
{
    public class BaseTraderInfoDTO
    {
        public double ProfitLoss { get; set; }
        public int CopyCount { get; set; }
    }
}