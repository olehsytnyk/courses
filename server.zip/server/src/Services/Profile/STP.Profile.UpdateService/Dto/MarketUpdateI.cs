﻿using System;
using STP.Interfaces.Messages;
using STP.Common.Models;


namespace STP.Profile.UpdateService.Dto
{
    public class MarketUpdateDtoI : MarketUpdateDto, IMessage
    {
    }
}
