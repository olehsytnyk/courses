﻿using System;
using System.Collections.Generic;
using System.Text;

namespace STP.Datafeed.Domain.DTOs
{
    public class MarketsIdsDto
    {
        public List<long> MarketsId = new List<long>();
    }
}
