﻿namespace STP.Interfaces
{
    public interface IOptions { }
}
