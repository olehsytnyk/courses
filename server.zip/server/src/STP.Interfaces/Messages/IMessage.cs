﻿namespace STP.Interfaces.Messages
{
    public interface IMessage
    {
    }
}

