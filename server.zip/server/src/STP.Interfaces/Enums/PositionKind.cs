﻿using System;
using System.Collections.Generic;
using System.Text;

namespace STP.Interfaces.Enums
{
    public enum PositionKind
    {
        Flat,
        Long,
        Short
    }

}
