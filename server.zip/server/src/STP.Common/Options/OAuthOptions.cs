﻿namespace STP.Common.Options
{
    public class OAuthOptions
    {
        public string AuthServer { get; set; }
        public string ApiName { get; set; }
    }
}
