﻿namespace STP.Common
{
    public class BaseOptions
    {
        public string ApiName { get; set; }
    }
}
