﻿using System;
using System.Collections.Generic;
using System.Text;

namespace STP.Common.Options
{
    public class HttpServiceOptions
    {
        public string ApiMarketsUrl { get; set; }
        public string ApiDatafeedUrl { get; set; }
        public string ApiProfileUrl { get; set; }
    }
}
