﻿namespace STP.Common
{
    public sealed class ConnectionStrings
    {
        public string LocalConnection { get; set; }
    }
}
